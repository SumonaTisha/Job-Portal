<?php

if(isset($_GET['id']))
{
	$dir="cred.txt";
	$id=$_GET['id'];
	
  $file=fopen($dir,"r") or die("file error");
	while($c=fgets($file))
{
	$ar=explode("-",$c);
		
	$d=0;
if($id==$ar[0])
{
    $file=fopen("data.txt","a") or die("file error");
    fwrite($file,"\n");	
	for($i=0;$i<sizeOf($ar);$i++)
	{
	fwrite($file,$ar[$i]);
	if($i<sizeOf($ar)-1)
	{   
     fwrite($file,"-");
	}
	}
	echo $_GET['id']."&nbsp Approved ";

	$contents = file_get_contents($dir);
	$contents = str_replace($c, '', $contents);
	file_put_contents($dir, $contents);
}
}
}
else
{
		echo "failed";
}

	
?>