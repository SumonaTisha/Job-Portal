

<!DOCTYPE html>
<html>
<head>
<title> company | Job Offer </title>
<style>
.nav-links  a {
			text-decoration: none;
		}
		.nav-links a:hover {
			color: blue;
		}
		
		.nav-links li {
			padding: 0 10px;
		}
</style>
</head>

<body style="background-color:powderblue;">
<h1 style="text-align:center;">Applicant Details </h1>
<form   align="center" , method="post"    > 

  
  
  
  
  <br><br>
<ul class="nav-links" >
	
	
	
	<li><a href="companyhome.php">Home</a></li>
	
	<li><a href="">Logout</a></li>
</ul>
</form>



</body>
</html>

<?php
$file=fopen("data.txt","r") or die("file error");

while($c=fgets($file))
{
	$ar=explode("-",$c);
	echo $ar[0]." ".$ar[1]."<br/>";
	echo "Phone: ".$ar[2].", email:".$ar[3]."<br/>";
	echo '<a href="aplic_approved.php?id='.$ar[0].'">Applicant Approval</a>';
	echo "<br/>";
	
	echo "<hr/>";
	
}

?>

