<!DOCTYPE html>
<html>
<head>
<title> View | Company </title>
<style>
.nav-links  a {
			text-decoration: none;
		}
		.nav-links a:hover {
			color: blue;
		}
		
		.nav-links li {
			padding: 0 10px;
		}
</style>
</head>

<body style="background-color:powderblue;">
<form   align="center" , method="post"    > 
<h1 style="text-align:center;">View Company</h1>
 <br><br>
<ul class="nav-links" >
	
	
	
	<li><a href="companyhome.php">Home</a></li>
		
	<li><a href=>logout</a></li>   
</ul>
<?php
//echo $_POST["uname"]."<br/>";
//echo $_POST["pass"];
//print_r($GLOBALS);

$cred=array();
$file=fopen("data1.txt","r") or die("file error");
while($c=fgets($file)){
	//echo $c."<br/>";
	$ar=explode("-",$c);
	//echo strlen($ar[0]).",,".strlen($ar[1])."<br/>";
	//$cred[$ar[0]]=trim($ar[1]);
	
	echo "Company Name:".$ar[0]."<br/>";
    echo "Company Address:".$ar[2]."<br/>";
	echo "Phone: ".$ar[3].", email:".$ar[4];
	echo "<hr/>";
	//echo '<a href="comp_approved.php?id='.$ar[0].'">Company Approval</a>';
	echo "<hr/>";
	
}
?>






</form>



</body>
</html>









