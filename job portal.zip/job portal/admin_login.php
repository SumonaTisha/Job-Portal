<html>
    <head>
    <style>
    <input margin:2px;>
    </style>
<title>
    login
</title>
    </head>
    <body style="background-color:powderblue;">
    <form align="center" action="server1.php">
	User Name
	<input value="" type="text" name="uname" /><br>
    password
    <input type="password" name="pass" /><br>
	
	<input type="submit" name="sbt" value="Login" /><br>
	 
   </form>
   <a href="main.html">Home</a><br/><br/><br/>
   
   
    </body>
</html>