<!DOCTYPE html>
<html>
<title> view | Company </title>
<style>

.nav-links {
			list-style: none; display: flex;
		}
		
		.nav-links li {
			padding: 0  30px;
		}
		
		.nav-links  a {
			text-decoration: none;
		}
		
		.nav-links a:hover {
			color: blue;
		}
		

</style>

<body style="background-color:powderblue;">
<form   align="center" action="viewcompany.php",   method="post"    > 
<h1 style="text-align:center;">View Company</h1>

<ul class="nav-links" >
	<li><a href="companyhome.php">home</a></li>
	<br/>
<br/>
<br/>
<br/><br/>
<br/><br/>
<br/><br/>
<br/><br/>
<br/><br/>
<br/>
	
	<li><a href=>logout</a></li>   
</ul>


</body>
</html>