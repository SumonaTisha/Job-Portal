<html>
    <head>
    <style>
    <input margin:2px>
    </style>
<title>signup</title>
    </head>
    <body style="background-color:powderblue;">
    <form align="center" action="regi_validate.php">
    Company Name:
    <input name="cname" type="text"><br/>
    Company Address:
    <input name="caname" type="text"><br/>
    Phone:
    <input name="number" type="text"><br>
    emailId:
    <input name="email" type="text"><br>
    password:
    <input name="pass" type="password"><br>
    confirm:
    <input name="comconfpass" type="password"><br>
	<input name="submit" type="submit" name="submit">
   </form>
    </body>
</html>

