<!DOCTYPE html>
<html>
<head>
	<title>Home | Company</title>
		<style>
		.nav-links {
			list-style: none; display: flex;
		}
		
		.nav-links li {
			padding: 0 40px;
		}
		
		.nav-links  a {
			text-decoration: none;
		}
		
		.nav-links a:hover {
			color: blue;
		}
		
	</style>
	
	
</head>
<body style="background-color:powderblue;">

<h1 style="text-align:center;">View Company Profile</h1>


<ul class="nav-links" >
	<li><a href="abc.php">view comapny  Profile</a></li>
	
	<li><a href="joboffer.php">Job Offer</a></li>
	<li><a href="applicant_approval.php">view Applicant </a></li>
	
	<li><a href="company_login.php">Logout</a></li>
	
</ul>


</body>
</html>