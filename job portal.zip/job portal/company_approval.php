<!DOCTYPE html>
<html>
<body style="background-color:powderblue;">
<h1 style="text-align:center;"> Company Details  </h1>

<a href="admin_home.php">Home</a>
<a href="admin_login.php">log out</a><br>

</body>
</html>
<?php
$file=fopen("singup.txt","r") or die("file error");

while($c=fgets($file))
{
	$ar=explode("-",$c);
	echo "Company Name:".$ar[0]."<br/>";
    echo "Company Address:".$ar[2]."<br/>";
	echo "Phone: ".$ar[3].", email:".$ar[4];
	echo "<hr/>";
	echo '<a href="comp_approved.php?id='.$ar[0].'">Company Approval</a>';
	echo "<hr/>";
	
}

?>
