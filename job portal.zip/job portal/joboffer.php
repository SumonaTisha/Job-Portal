<!DOCTYPE html>
<html>
<head>
<title> company | Job Offer </title>
<style>
.nav-links  a {
			text-decoration: none;
		}
		.nav-links a:hover {
			color: blue;
		}
		
		.nav-links li {
			padding: 0 10px;
		}
</style>
</head>

<body style="background-color:powderblue;">
<h1 style="text-align:center;">Job Offer Form</h1>
<form   align="center" action="offer.php",   method="post"    > 

  Job name:<br>
  <input type="text" name="jobname" >
  <br>
  Education:<br>
  <input type="text" name="education" >
  <br>
  Job Description:<br>
  <input type="text" name="jobdescription" >
  <br>
  Skill:<br>
  <input type="text" name="skill" >
  <br>
  Location:<br>
  <input type="text" name="location" >
  <br>
  
  
  
  
  <br><br>
<ul class="nav-links" >
	
	<li><a href="admin_approval.php">Submit</a></li>
	
	<li><a href="companyhome.php">Home</a></li>
</ul>
</form>



</body>
</html>
