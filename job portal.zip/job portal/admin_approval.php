<!DOCTYPE html>
<html>
<head>
<title> Admin | Approve </title>
<style>

.nav-links {
			list-style: none; display: flex;
		}
		
		.nav-links li {
			padding: 0  30px;
		}
		
		.nav-links  a {
			text-decoration: none;
		}
		
		.nav-links a:hover {
			color: blue;
		}
		

</style>
</head>  


<body style="background-color:powderblue;">
<h1 style="text-align:center;">Admin Approval</h1>
<br/>
<ul class="nav-links" >
	
	<li><a href="companyhome.php">home</a></li>
	<br/>
<br/>
<br/>
<br/><br/>
<br/><br/>
<br/><br/>
<br/><br/>
<br/><br/>
<br/>
	
	<li><a href=>logout</a></li>   
</ul>


</body>
</html>

