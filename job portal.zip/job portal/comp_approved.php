<?php

if(isset($_GET['id']))
{
	$dir="singup.txt";
	$id=$_GET['id'];
	
  $file=fopen($dir,"r") or die("file error");
	while($c=fgets($file))
{
	$ar=explode("-",$c);
		
	$d=0;
	fwrite($file,"\r\n");
if($id==$ar[0])
{    
    $file=fopen("data1.txt","a") or die("file error");	
    //fwrite($file,"\r\n");
	for($i=0;$i<sizeOf($ar);$i++)
	{
	fwrite($file,$ar[$i]);
	if($i<sizeOf($ar)-1)
	{   
     fwrite($file,"-");
	}
	}
	//fwrite($file,"\n");
	//fwrite($file,"\n");
	echo $_GET['id']."&nbsp Approved ";

	$contents = file_get_contents($dir);
	$contents = str_replace($c, '', $contents);
	file_put_contents($dir, $contents);
}
}
}
else
{
		echo "failed";
}

	
?>