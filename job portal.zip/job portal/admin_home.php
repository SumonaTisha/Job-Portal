<!DOCTYPE html>
<html>

<body style="background-color:powderblue;">
<h1 style="text-align:center;"> Admin  </h1>

<a href="company_approval.php">Company Approval </a>
<br/><br/>
<a href="applicant_approval.php">Applicant Approval </a>
<br/><br/>
<a href="admin_login.php">log out</a>

</body>
</html>