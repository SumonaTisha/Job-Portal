<?php


$file=fopen('joboffer.txt','a') or die("fle open error");
$c=0;

if(strlen($_POST["jobname"])==0){
	echo "<p style='color:red'>Must type jobname Name!</p>";
}
else if(strlen($_POST["education"])==0 ){
	echo "<p style='color:red'>must type education!</p>";
}
else if(strlen($_POST["jobdescription"])==0){
	echo "<p style='color:red'>Must type  Job Description!</p>";
}
else if(strlen($_POST["skill"])==0){
	echo "<p style='color:red'>Must type  Job Skill!</p>";
}
else if(strlen($_POST["location"])==0){
	echo "<p style='color:red'>Must type  Job Skill!</p>";
}



if($_REQUEST["jobname"]==0){
	$c=$c+fwrite($file,"\r\n");
	$c=$c+fwrite($file,$_REQUEST["jobname"]);
	$c=$c+fwrite($file,"-");
	$c=$c+fwrite($file,$_REQUEST["education"]);
	$c=$c+fwrite($file,"-");
	$c=$c+fwrite($file,$_REQUEST["jobdescription"]);
	$c=$c+fwrite($file,"-");
	$c=$c+fwrite($file,($_REQUEST["skill"]));
	$c=$c+fwrite($file,"-");
	$c=$c+fwrite($file,($_REQUEST["location"]));
	
}






?>


